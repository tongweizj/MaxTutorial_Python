from distutils.core import setup

setup(
	name          = 'nester',
	version       = '1.1.1',
	py_modules    = ['nester'],
	author        = 'wtong',
	author_email  = 'wtong@yoese.com',
	url			  = 'http://yoese.com',
	description   = 'A simple printer',

	)